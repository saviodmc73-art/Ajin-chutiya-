AJIN CHUTIYA UNIVERSITY - exam countdown dashboard + private arcade
===================================================================

OPEN IT
- Double-click index.html (works offline), or upload the whole folder to any static host.
- Keep the folder structure exactly as it is. Do not upload index.html alone.

FILES
index.html            Dashboard: countdown, ticking sound, study vault, timetable, arcade gate
arcade.html           Private arcade: Reunion Maze + Ajin Flappy (only opens after the gate)
assets/heavenly-top.png   Hero photo (full photo, shown directly under the header)
assets/heavenly-hero.png  Soft blurred atmospheric background version
assets/ajin-player.png    Maze player + Flappy character (portrait crop)
assets/maze-target.png    Maze destination character (portrait crop)
assets/exam-timetable.jpg Timetable image
assets/victory.mp3        Plays when the maze is completed
assets/death-noise.mp3    Plays on Flappy game over
question-papers/semester, question-papers/internal   Original PDFs (unmodified)

COMMON CHANGES
- Exam date/time: edit EXAM_TS near the top of the script in index.html (ISO format, +05:30 = IST).
- Swap a portrait: replace assets/ajin-player.png or assets/maze-target.png (square PNG, ~400x400).
- Add a question paper: put the PDF in question-papers/, then add one line to the PAPERS list in index.html.
- Change the arcade code: the code is stored only as a SHA-256 fingerprint (GATE_HASH in index.html).
  Make a new one with:   echo -n "NEWCODE" | sha256sum    (use UPPERCASE letters) and paste it in.
  Note: this is a fun gate, not real security - anyone who can read the page code could bypass it.

NOTES
- Ticking uses the Web Audio API (no audio file). It starts after your first tap/click (browser rule),
  stops when the tab is hidden, minimised or the window loses focus, and resumes on return.
  Turn it on/off in MENU.
- Your own uploaded PDFs are stored in your browser only (IndexedDB), not on a server.
